package fundatec.com.demo.DTO;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_planoDTO")
public class PlanoDTO {

}
