package fundatec.com.demo.service;

import fundatec.com.demo.model.Tarifa;
import fundatec.com.demo.repository.TarifaRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TarifaService {
    private final TarifaRepository tarifaRepository;

    public TarifaService(TarifaRepository tarifaRepository) {
        this.tarifaRepository = tarifaRepository;
    }



    public Tarifa salvar(Tarifa tarifa) {
        return tarifaRepository.save(tarifa);
    }

    public void delete(Long id) {
        tarifaRepository.deleteById(id);
    }


    public Tarifa editar(Long idTarifa , Tarifa tarifa) {
        Optional<Tarifa> tarifa1 = tarifaRepository.findById(idTarifa);
        if (tarifa1 == null) {
            throw new RuntimeException("Não existente" + tarifa.getIdTarifa());
        }

        return tarifaRepository.save(tarifa);
    }


    public Optional<Tarifa> findById(Long id) {
        return tarifaRepository.findById(id);
    }

    public Iterable<Tarifa> findAll() {
        return tarifaRepository.findAll();
    }

    public Optional<Tarifa> findByLike(Long id) {
        return tarifaRepository.findById(id);
    }
}













