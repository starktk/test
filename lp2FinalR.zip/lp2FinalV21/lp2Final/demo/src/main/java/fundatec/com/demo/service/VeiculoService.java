package fundatec.com.demo.service;

import fundatec.com.demo.DTO.VeiculoDTO;
import fundatec.com.demo.model.Veiculo;
import fundatec.com.demo.repository.VeiculoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VeiculoService {

    private final VeiculoRepository veiculoRepository;

    public VeiculoService(VeiculoRepository veiculoRepository) {
        this.veiculoRepository = veiculoRepository;

    }

    public Veiculo criar(Veiculo veiculo) {
        return veiculoRepository.save(veiculo);
    }

    public Veiculo editar(Long idVeiculo , Veiculo veiculo) {

        Optional<Veiculo> veiculo1 = veiculoRepository.findById(idVeiculo);
        if (veiculo1 == null) {
            throw new RuntimeException("Não existente" + veiculo.getIdVeiculo());
        }

        return veiculoRepository.save(veiculo);
    }


    public Optional<Veiculo> pesquisar(Long idVeiculo) {
        return veiculoRepository.findById(idVeiculo);
    }

    public Veiculo pesquisarDTO(Long idVeiculo){
        return veiculoRepository.getById(idVeiculo);
    }


    public void delete(Long id) {
        veiculoRepository.deleteById(id);
    }

}
