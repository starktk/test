package fundatec.com.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Objects;

/**
 * Classe acrescentada
 * Inclusão do método
 *
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */
@Entity
@Table(name = "tb_carro")
public class Carro extends Veiculo {
    @Column
    private Long id;

    public Carro() {

    }

    public Carro(Long id) {
        this.id = id;
    }

    public Carro(Long id, TipoVeiculo tipo, String placa, Cliente cliente, Tarifa tarifa, Long id1) {
        super(id, tipo, placa, cliente, tarifa);
        this.id = id1;
    }

    @Override
    public Long getIdVeiculo() {
        return id;
    }

    @Override
    public void setIdVeiculo(Long idVeiculo) {
        this.id = idVeiculo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Carro carro)) return false;
        if (!super.equals(o)) return false;
        return id.equals(carro.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), id);
    }

//public Carro() {
    // super(taxaMeiaHora:10, taxaUmaHora:15, taxaHoraAdicional:5, taxaDiaria:30);
    //this.id = id;
    //}


}
