package fundatec.com.demo.service;

import fundatec.com.demo.model.Cliente;
import fundatec.com.demo.repository.PlanoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Vide blog professor
 * Métodos segundo o blog
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */
@Service
public class PlanoService {

    private final PlanoRepository planoRepository;

    public PlanoService(PlanoRepository planoRepository) {
        this.planoRepository = planoRepository;
    }

    ResponseEntity create(@RequestBody Cliente cliente) {

    }

}
