package fundatec.com.demo.model;

import jakarta.persistence.*;

import java.util.Objects;

/**
 * Foi colocado um relacionamento no atributo cliente muitos para um
 * E o @Table com o nome da tabela
 * Anotações como @Enumerated indicando o Enum
 */
@Entity
@Table(name = "tb_veiculo")
@Inheritance(strategy = InheritanceType.JOINED)
public class Veiculo {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idVeiculo;
    @Column
    @Enumerated(EnumType.STRING)
    private TipoVeiculo tipo;
    @Column(nullable = false)
    private String placa;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "cliente_id", referencedColumnName = "id", nullable = false)
    private Cliente cliente;
    @OneToMany(mappedBy = "veiculo")
    private Tarifa tarifa;

    public Veiculo() {

    }

    public Veiculo(Long idVeiculo, TipoVeiculo tipo, String placa, Cliente cliente, Tarifa tarifa) {
        this.idVeiculo = idVeiculo;
        this.tipo = tipo;
        this.placa = placa;
        this.cliente = cliente;
        this.tarifa = tarifa;
    }


    public Long getIdVeiculo() {
        return idVeiculo;
    }

    public void setIdVeiculo(Long idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    public TipoVeiculo getTipo() {
        return tipo;
    }

    public void setTipo(TipoVeiculo tipo) {
        this.tipo = tipo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Tarifa getTarifa() {
        return tarifa;
    }

    public void setTarifa(Tarifa tarifa) {
        this.tarifa = tarifa;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Veiculo veiculo)) return false;
        return idVeiculo.equals(veiculo.idVeiculo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idVeiculo);
    }
}
