package fundatec.com.demo.model;

public enum TipoVeiculo {
    CARRO, MOTO, BICICLETA
}
