package fundatec.com.demo.service;

import fundatec.com.demo.model.Endereco;
import fundatec.com.demo.model.TarifaPorTipo;
import fundatec.com.demo.repository.EnderecoRepository;
import fundatec.com.demo.repository.TarifaPorTipoRepository;

import java.util.Optional;

public class TarifaPorTipoService{

    private final TarifaPorTipoRepository tarifaPorTipoRepository;

    public TarifaPorTipoService(TarifaPorTipoRepository tarifaPorTipoRepository) {
        this.tarifaPorTipoRepository = tarifaPorTipoRepository;
    }


    public TarifaPorTipo criar(TarifaPorTipo tarifaPorTipo) {
        return tarifaPorTipoRepository.save(tarifaPorTipo);
    }


    public Optional<TarifaPorTipo> pesquisar(Long idTarifaPorTipo) {
        return tarifaPorTipoRepository.findById(idTarifaPorTipo);
    }

}
