package fundatec.com.demo.controller;

import fundatec.com.demo.DTO.EnderecoDTO;
import fundatec.com.demo.model.Cliente;
import fundatec.com.demo.model.Endereco;
import fundatec.com.demo.service.ClienteService;
import fundatec.com.demo.service.EnderecoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


/**
 * Método PostMapping acrecentado vide blog professor
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */
@RestController
@RequestMapping(path = "/endereco")

public class EnderecoCtrl {

    private final EnderecoService enderecoService;
    private final ClienteService clienteService;

    public EnderecoCtrl(EnderecoService enderecoService, ClienteService clienteService) {
        this.enderecoService = enderecoService;
        this.clienteService = clienteService;
    }

    @PostMapping
    public ResponseEntity criar(@RequestBody EnderecoDTO enderecoDTO) {
        Cliente cliente = clienteService.pesquisarDto(enderecoDTO.getIdCliente());
        if (cliente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(" Não foi encontrado o cliente " + enderecoDTO.getIdCliente());
        }
        Endereco endereco1 = new Endereco();
        endereco1.setCidade(enderecoDTO.getCidade());
        endereco1.setCep(enderecoDTO.getCep());
        endereco1.setEstado(enderecoDTO.getEstado());
        endereco1.setCliente(cliente);
        endereco1.setRua(enderecoDTO.getRua());
        endereco1.setNumero(enderecoDTO.getNumero());
        endereco1.setBairro(enderecoDTO.getBairro());


        enderecoService.criar(endereco1);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity editar(@RequestBody EnderecoDTO enderecoDTO, @PathVariable Long idEndereco) {
        Endereco endereco = enderecoService.pesquisarDto(enderecoDTO.getIdEndereco());
        if (endereco == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(" Não foi encontrado o endereco de id " + idEndereco);
        }
        Endereco endereco1 = new Endereco();
        endereco1.setCidade(enderecoDTO.getCidade());
        endereco1.setCep(enderecoDTO.getCep());
        endereco1.setEstado(enderecoDTO.getEstado());
        endereco1.setRua(enderecoDTO.getRua());
        endereco1.setNumero(enderecoDTO.getNumero());
        endereco1.setBairro(enderecoDTO.getBairro());

        enderecoService.editar(enderecoDTO.getIdEndereco() , endereco1);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long idEndereco){
        enderecoService.deletar(idEndereco);

    }

    @GetMapping
    public Optional<Endereco> pesquisar(@PathVariable Long idEndereco){
        return enderecoService.pesquisar(idEndereco);
    }
}



