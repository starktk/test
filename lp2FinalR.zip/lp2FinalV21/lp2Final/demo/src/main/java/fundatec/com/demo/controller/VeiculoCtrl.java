package fundatec.com.demo.controller;

import fundatec.com.demo.model.Veiculo;
import fundatec.com.demo.service.VeiculoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/Veiculo")
public class VeiculoCtrl {
    private final VeiculoService veiculoService;

    public VeiculoCtrl(VeiculoService veiculoService) {
        this.veiculoService = veiculoService;

    }

    @PostMapping
    public Veiculo criar(@RequestBody Veiculo veiculo) {
        return veiculoService.criar(veiculo);
    }

    @PutMapping
    public ResponseEntity editar(@RequestBody Veiculo veiculo , @PathVariable Long idVeiculo) {
        Veiculo veiculo1 = veiculoService.pesquisarDTO(idVeiculo);
        if (veiculo1 == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Veiculo não encontrado!" + idVeiculo);
        }

        veiculoService.editar(idVeiculo , veiculo);
        return ResponseEntity.status(HttpStatus.OK).build();

    }

    @GetMapping("/{id}")
    public ResponseEntity pesquisar(@PathVariable Long idVeiculo) {
        Optional<Veiculo> optionalVehicle = veiculoService.pesquisar(idVeiculo);
        if (optionalVehicle == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Veiculo não encontrado!" + idVeiculo);

        }


        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        veiculoService.delete(id);
    }


}
