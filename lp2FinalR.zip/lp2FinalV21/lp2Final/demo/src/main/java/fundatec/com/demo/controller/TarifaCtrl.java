package fundatec.com.demo.controller;

import fundatec.com.demo.model.Tarifa;
import fundatec.com.demo.service.TarifaService;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/Tarifa")
public class TarifaCtrl {

    private final TarifaService tarifaService;

    public TarifaCtrl(TarifaService tarifaService) {
        this.tarifaService = tarifaService;
    }

    @PostMapping
    public Tarifa criar(@RequestBody Tarifa tarifa) {
        return tarifaService.salvar(tarifa);
    }

    @PutMapping
    public Tarifa editar(@RequestBody Tarifa tarifa) {
        return tarifaService.salvar(tarifa);
    }

    @GetMapping("/{id}")
    public Tarifa findTarifaById(@PathVariable Long id) {
        Optional<Tarifa> optionalTax = tarifaService.findById(id);
        if (optionalTax.isPresent())
            return optionalTax.get();

        return null;
    }

    @GetMapping
    public Iterable<Tarifa> findAll() {
        return tarifaService.findAll();
    }



    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        tarifaService.delete(id);
    }

    @GetMapping("/")
    public Tarifa findByLike(@RequestParam("id") Long id) {
        Optional<Tarifa> optionalTax= tarifaService.findByLike(id);
        if (optionalTax.isPresent())
            return optionalTax.get();

        return null;
    }
}