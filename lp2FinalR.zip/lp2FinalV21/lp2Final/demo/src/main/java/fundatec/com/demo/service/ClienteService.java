package fundatec.com.demo.service;

import fundatec.com.demo.model.Cliente;
import fundatec.com.demo.repository.ClienteRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * ClienteService parâmetros corrigidos
 * Cliente create ao invés do criar e foi acrescentada a entity substituindo o cliente
 * Cliente findById
 *
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */
@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public ClienteService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }


    public Cliente create(Cliente cliente) {
        return clienteRepository.save(cliente);
    }


    public Cliente pesquisarDto(Long idCliente) {
        return clienteRepository.getById(idCliente);
    }

    public Optional<Cliente> pesquisar(Long idCliente) {
        return clienteRepository.findById(idCliente);
    }

    public void deletar(Long idCliente) {
        clienteRepository.deleteById(idCliente);
    }

    public Cliente editar(Long idCliente, Cliente cliente) {
        Optional<Cliente> cliente1 = clienteRepository.findById(idCliente);
        if (cliente1 == null) {
            throw new RuntimeException("Não existente" + cliente.getId());
        }

        return clienteRepository.save(cliente);
    }

    public Cliente findByCPF(String cpf) {
        return clienteRepository.findByCpf(cpf);
    }
}
