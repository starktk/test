package fundatec.com.demo.repository;

import fundatec.com.demo.model.Cliente;
import fundatec.com.demo.model.Plano;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Inclusão dos métodos seguindo o trabalho do professor no blog
 * @author Marcela
 * @since 22/01/2023
 * @version 2.1
 *
 */
@Repository
public interface PlanoRepository extends JpaRepository<Plano, Long> {
    Plano findByAssinante(Cliente assinante);

    @Query("select c from Plano c join c.assinante a where a.id=:id ")
    Plano findByAssinanteId(@Param("id") Long id);

    PlanoDTO findPlanoDTOByAssinanteId(@Param("id") Long id);

}

