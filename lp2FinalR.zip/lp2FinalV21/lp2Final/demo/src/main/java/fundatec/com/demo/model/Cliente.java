package fundatec.com.demo.model;

import jakarta.persistence.*;

import java.util.Objects;

/**
 * Troquei Integer cpf por String cpf como está no diagrama
 * Nas dependências foram acrescentados os drivers do mysql e jakarta
 * O plano isAssinante foi completado
 * Na classes ClienteRepository e ClienteService foram acrecentados o método findByCpf
 * Incluso relacionamento um pra um das classes Cliente e Endereço
 * Incluso relacionamento um pra muitos da classe Cliente e muitos para um da classe Plano.
 * Foi alterado OneToOne do atributo plano para @Column
 * Acrescentado @Table com o nome da tabela
 * @since 21/01/2023
 * @author Marcela
 * @version 2.0
 */
@Entity
@Table(name = "tb_cliente")
public class Cliente {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCliente;
    @Column(length = 100, name = "Nome")
    private String nome;
    @Column(length = 11, name = "Cpf", unique = true)
    private String cpf;

    @OneToMany(mappedBy = "assinante")
    private Plano plano;


    @OneToOne(mappedBy = "cliente")
    private Endereco endereco;

    public Cliente() {

    }

    public Cliente(Long idCliente, String nome, String cpf, Plano plano, Endereco endereco) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.cpf = cpf;
        this.plano = plano;
        this.endereco = endereco;
    }

    public Long getId() {
        return idCliente;
    }

    public void setIdCliente(Long idCliente) {
        this.idCliente = idCliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Plano getPlano() {
        return plano;
    }

    public void setPlano(Plano plano) {
        this.plano = plano;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public boolean isAssinante() {
        throw new UnsupportedOperationException();


    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cliente cliente)) return false;
        return idCliente.equals(cliente.idCliente);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCliente);
    }
}
