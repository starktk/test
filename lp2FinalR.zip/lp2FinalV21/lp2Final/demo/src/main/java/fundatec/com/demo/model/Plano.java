package fundatec.com.demo.model;

import jakarta.persistence.*;

import java.util.Objects;

/**
 * Foi alterado no atributo cliente a anotação @OneToOne(mappedBy="plano",optional=false)
 * para muitos para um e restante da anotação que faz referência a assinante_id
 */
@Entity
@Table(name="tb_plano")
public class Plano {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(length = 100, name = "Id_Plano")
    private Long id;

    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="assinante_id", referencedColumnName = "id")
    private Cliente assinante;

    @Column(length = 5, name = "Valor")
    private Double valor;


    public Plano() {


    }

    public Plano(Long id, Cliente assinante, Double valor) {
        this.id = id;
        this.assinante = assinante;
        this.valor = valor;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cliente getAssinante() {
        return assinante;
    }

    public void setAssinante(Cliente assinante) {
        this.assinante = assinante;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Plano)) return false;
        Plano plano = (Plano) o;
        return id.equals(plano.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}