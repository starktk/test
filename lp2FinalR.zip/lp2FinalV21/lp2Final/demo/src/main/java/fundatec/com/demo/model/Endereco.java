package fundatec.com.demo.model;

import jakarta.persistence.*;

import java.util.Objects;

/**
 * Acrescentou-se nullable false para o atributo endereço que deve estar completo
 *
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */

@Entity
@Table(name = "tb_endereco")
public class Endereco {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_endereco;

    @OneToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Column(length = 200, name = "Rua", nullable = false)
    private String rua;

    @Column(length = 8, name = "Numero", nullable = false)
    private Integer numero;
    @Column(length = 100, name = "Bairro", nullable = false)
    private String bairro;
    @Column(length = 9, name = "Cep", nullable = false)
    private Integer cep;
    @Column(length = 50, name = "Cidade", nullable = false)
    private String cidade;
    @Column(length = 70, name = "Estado", nullable = false)
    private String estado;

    public Endereco() {

    }

    public Endereco(Integer id_endereco, Cliente cliente, String rua, Integer numero, String bairro, Integer cep, String cidade, String estado) {
        this.id_endereco = id_endereco;
        this.cliente = cliente;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cep = cep;
        this.cidade = cidade;
        this.estado = estado;
    }

    public Integer getId() {
        return id_endereco;
    }

    public void setId(Integer id_endereco) {
       this.id_endereco = id_endereco;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public Integer getCep() {
        return cep;
    }

    public void setCep(Integer cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Endereco endereco)) return false;
        return id_endereco == endereco.id_endereco;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_endereco);
    }
}



