package fundatec.com.demo.controller;

import fundatec.com.demo.DTO.ClienteDTO;
import fundatec.com.demo.model.Cliente;
import fundatec.com.demo.model.Endereco;
import fundatec.com.demo.service.ClienteService;
import fundatec.com.demo.service.EnderecoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * Acrescentado o atributo private final EnderecoService enderecoService,vide blog do professor
 * Construtor corrigido nos parâmetros
 * Faltam as classes DTO
 * @author Marcela
 * @since 22/01/2023
 * @version 2.1
 */

@RestController
@RequestMapping(path = "/cliente")
public class ClienteCtrl {

    private final ClienteService clienteService;
    private final EnderecoService enderecoService;

    public ClienteCtrl(ClienteService clienteService, EnderecoService enderecoService) {
        this.clienteService = clienteService;
        this.enderecoService = enderecoService;
    }

    @PostMapping
    public ResponseEntity create(@RequestBody ClienteDTO clienteDTO) {
        Endereco endereco = enderecoService.pesquisarDto(clienteDTO.getIdEndereco());
        if (endereco == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Não foi encontrado o endereco de id" + clienteDTO.getIdEndereco());
        }
        Cliente cliente = new Cliente();
        cliente.setCpf(clienteDTO.getCpf());
        cliente.setNome(clienteDTO.getNome());
        cliente.setEndereco(endereco);
        clienteService.create(cliente);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity editar(@RequestBody ClienteDTO clienteDTO, @PathVariable Long id) {
        Cliente cliente1 = clienteService.pesquisarDto(clienteDTO.getIdCliente());
        Endereco endereco = enderecoService.pesquisarDto(clienteDTO.getIdEndereco());
        if (cliente1 == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Não foi encontrado o cliente de id " + id);

        }

        Cliente cliente = new Cliente();
        cliente.setCpf(clienteDTO.getCpf());
        cliente.setNome(clienteDTO.getNome());
        cliente.setEndereco(endereco);
        clienteService.editar(clienteDTO.getIdCliente(), cliente);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long idCliente){
        enderecoService.deletar(idCliente);
    }

    @GetMapping("/{id}")
    public Optional<Cliente> pesquisar(@PathVariable Long idCliente){
        return clienteService.pesquisar(idCliente);
    }

    @GetMapping("BuscaCpf")
    public Cliente pesquisar(@RequestParam String cpf){
        return clienteService.findByCPF(cpf);
    }
}
