package fundatec.com.demo.service;

public class EstacionamentoService {
}
