package fundatec.com.demo.controller;

import fundatec.com.demo.model.Cliente;
import fundatec.com.demo.model.Endereco;
import fundatec.com.demo.model.Plano;
import fundatec.com.demo.service.EnderecoService;
import fundatec.com.demo.service.PlanoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Métodos acrescentados baseados no trabalho postado no blog do professor
 * @author Marcela
 * @since 22/01/2023
 * @version 2.1
 */
@RestController
@RequestMapping(path="/plano")
public class PlanoCtrl {
    private final PlanoService planoService;

    public PlanoCtrl(PlanoService planoService) {
        this.planoService = planoService;
    }
}