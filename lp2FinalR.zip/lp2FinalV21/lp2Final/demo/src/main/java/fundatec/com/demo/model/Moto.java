package fundatec.com.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Objects;

/**
 * Classe acrescentada
 * Inclusa classe Moto
 * Ver blog professor https://blog.gsilva.pro/trabalho-final-t21-fundatec-detalhamento-parte-1
 * No trabalho do git, o qual o blog cita logo no início, há três classes que herdam a classe veiculo,carro, moto e bicicleta.
 * No diagrama do trabalho final constam apenas carro e moto.
 * Há apenas um construtor default com a indicação do super contendo as taxas.
 *
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */
@Entity
@Table(name = "tb_moto")
public class Moto extends Veiculo {
    @Column
    private Long id;

    public Moto() {

    }

    public Moto(Long id) {
        this.id = id;
    }

    public Moto(Long id, TipoVeiculo tipo, String placa, Cliente cliente, Tarifa tarifa, Long id1) {
        super(id, tipo, placa, cliente, tarifa);
        this.id = id1;
    }

// public Moto() {
    // super(taxaAteMeiaHora:7, taxaAteUmaHora:10, taxaHoraAdicional:3, taxaDiaria:20);
    //this.id = id;
    //}

    public Long getIdVeiculo() {
        return id;
    }

    public void setIdVeiculo(Long idVeiculo) {
        this.id = idVeiculo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Moto moto)) return false;
        return id.equals(moto.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
