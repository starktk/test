package fundatec.com.demo.service;

import fundatec.com.demo.DTO.EnderecoDTO;
import fundatec.com.demo.model.Endereco;
import fundatec.com.demo.repository.EnderecoRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Tudo que aparece como comentado é o que anteriormente estava feito no arquivo
 * O que nao aparece foi modificado
 * vide blog professor as classes do trabalho implementadas
 * @author Marcela
 * @since 22/01/2023
 * @version 2.1
 */
@Service
public class EnderecoService {

    private final EnderecoRepository enderecoRepository;

    public EnderecoService(EnderecoRepository enderecoRepository) {
        this.enderecoRepository = enderecoRepository;
    }

    public Endereco criar(Endereco entity) {
        return this.enderecoRepository.save(entity);
    }

    public Endereco pesquisarDto(Long idEndereco) {
        return enderecoRepository.getById(idEndereco);
    }

    public Optional<Endereco> pesquisar(Long idEndereco) {
        return this.enderecoRepository.findById(idEndereco);
    }
    public Endereco editar(Long idEndereco, Endereco endereco){
        Optional<Endereco> endereco1 = enderecoRepository.findById(idEndereco);
        if(endereco1 == null){
            throw new RuntimeException("Não foi encontrado o id desejado! " + idEndereco);
        }
        return enderecoRepository.save(endereco);
    }

    public void deletar (Long idEndereco){
        enderecoRepository.deleteById(idEndereco);
    }

}
