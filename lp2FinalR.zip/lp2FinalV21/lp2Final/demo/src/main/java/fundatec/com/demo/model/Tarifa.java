package fundatec.com.demo.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

/**
 * Acrescentado o Método Double CalcularTarifa
 * Foi
 *
 * @author Marcela
 * @version 2.1
 * @since 22/01/2023
 */
@Entity
@Table(name = "tb_tarifa")
public class Tarifa {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTarifa;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "veiculo_id", referencedColumnName = "id")
    private Veiculo veiculo;
    @Column
    private LocalDateTime entrada;
    @Column
    private LocalDateTime saida;
    @Column
    private Double valorPago;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "estacionamento_id", referencedColumnName = "id")
    private Estacionamento estacionamento;

    public Tarifa() {

    }

    public Tarifa(Long idTarifa, Veiculo veiculo, LocalDateTime entrada, LocalDateTime saida, Double valorPago, Estacionamento estacionamento) {
        this.idTarifa = idTarifa;
        this.veiculo = veiculo;
        this.entrada = entrada;
        this.saida = saida;
        this.valorPago = valorPago;
        this.estacionamento = estacionamento;
    }

    public Double calcularTarifa(LocalDateTime saida, Boolean isAssinante, TarifaPorTipo tarifas) {
        Long tempoEstacionamento = ChronoUnit.MINUTES.between(entrada, saida);
        double tarifa = 0;
        if (tempoEstacionamento <= 0) {
            throw new RuntimeException("Tempo de estacionamento não pode ser menor ou igual a 0");
        }
        if (tempoEstacionamento <= 30.) {
           tarifa = tarifas.getTaxaAteMeiaHora();
        }
        if (tempoEstacionamento > 30 && tempoEstacionamento <= 60 ) {
            tarifa = tarifas.getTaxaAteUmaHora();
        }
        if (tempoEstacionamento > 60 && tempoEstacionamento <= 600) {
            tarifa = tarifas.getTaxaAteUmaHora() + (tempoEstacionamento -1) * tarifas.getTaxaHoraAdicional();
        }
        if (tempoEstacionamento > 600) {
            tarifa = tarifas.getTaxaDiaria();
        }
        if (isAssinante) {
            return tarifa * 0.85;
        }
        return tarifa;
    }


    public Long getIdTarifa() {
        return idTarifa;
    }


    public void setIdTarifa(Long idTarifa) {
        this.idTarifa = idTarifa;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public LocalDateTime getEntrada() {
        return entrada;
    }

    public void setEntrada(LocalDateTime entrada) {
        this.entrada = entrada;
    }

    public LocalDateTime getSaida() {
        return saida;
    }

    public void setSaida(LocalDateTime saida) {
        this.saida = saida;
    }

    public Double getValorPago() {
        return valorPago;
    }

    public void setValorPago(Double valorPago) {
        this.valorPago = valorPago;
    }

    public Estacionamento getEstacionamento() {
        return estacionamento;
    }

    public void setEstacionamento(Estacionamento estacionamento) {
        this.estacionamento = estacionamento;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tarifa tarifa)) return false;
        return idTarifa.equals(tarifa.idTarifa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTarifa);
    }
}


